#pragma once
#include <SFML\Graphics.hpp>
#include <vector>
#include <math.h>

#include "GameObjects.h"
#include "Timer.h"






class Enemy_spawner
{
private:
	int number_of_objects;
	int curr_object;

	std::vector<Enemy> objects;
	Timer timer;

public:

	Enemy_spawner(Enemy enemy,int number_of_objects):number_of_objects(number_of_objects),curr_object(0)
	{
		srand(time(0));
		for (int i = 0; i < number_of_objects; i++)
		{
			objects.push_back(enemy);
		}

		for (int i = 0; i < number_of_objects; i++)
		{
			objects[i].setPosition(rand() % 1440,0); //nie powinno tu byc stalej, moze kiedys zmienie
		}

	}




	void draw(sf::RenderWindow &window)
	{
		for (int i = 0; i < objects.size(); i++)
		{
			if (objects[i].exists)
			{
				objects[i].draw(window);
			}
		}
	}

	bool all_died()
	{
		for (int i = 0; i < objects.size(); i++)
		{
			if (!objects[i].died)
				return false;
		}

		return true;

	}


	void spawn(int delay)
	{


		if (curr_object < number_of_objects)
		{
			if (timer.Basic_spawner(delay))
			{
				objects[curr_object].exists = true;

				curr_object++;
			}
		}

	}

	void AI_move_with_surround(float x, float y,Player &player,int distance_to_attack)
	{

		for (int i = 0; i < objects.size();i++)
			if (objects[i].exists)
			{
				//te 3 linijki zeby ustawial sie przodem do gracza ;)
				float radian = atan2(player.getPosition().x-objects[i].getPosition().x, player.getPosition().y - objects[i].getPosition().y);
				float angle = 180 * radian / M_PI;
				objects[i].setRotation(-angle+180);

				sf::Vector2f distance = player.getPosition() - objects[i].getPosition();
				float distance_from_player = sqrtf(distance.x*distance.x + distance.y*distance.y);



				if (distance_from_player > distance_to_attack)
				{
					objects[i].too_close = false;
					objects[i].move_to_player(x, y, player);
				}

				else if(distance_from_player<=distance_to_attack&&distance_from_player>200&&objects[i].too_close==false)
				{
					if (i % 2 == 0)
					{
						objects[i].move_around(x, y, player);
					}
				else
					{
					objects[i].move_around(-x, -y, player);
					}
				}

				else
				{
					objects[i].too_close = true;
					objects[i].move_to_player(-x*3, -y*3, player);
				}


			}
	}


	void collision_with_player(Player &player)
	{
		for (int i = 0; i < objects.size(); i++)
		{
			if (objects[i].check_collision(player)&&timer.Basic_spawner(1000))
			{
				player.get_damage(5);
				std::cout << "Kolizja" << std::endl;
			}
		}
	}


	std::vector<Enemy>& return_objects()
	{
		return this->objects;
	}




	~Enemy_spawner()
	{
		objects.clear();
	}








};

