#include <iostream>
#include <string>
#include <time.h>
#include <math.h>

#include <SFML\Graphics.hpp>
#include <SFML/Window.hpp>


#include "GameObjects.h"
#include "Weapons.h"
#include "Timer.h"
#include "Spawner.h"
#include "Interface.h"

int main()
{
	//////////////////////////////////////////////////////////////////////////////////////////////////
	//rozmiary okna
	static const int ScreenHeight = 900;
	static const int ScreenWidth = 1440;

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//okno
	sf::RenderWindow MainWindow(sf::VideoMode(ScreenWidth, ScreenHeight), "Game");
	MainWindow.setVerticalSyncEnabled(true);
	MainWindow.setFramerateLimit(60);
	sf::Event event;

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//Tlo
	sf::Texture theme_texture;
	theme_texture.loadFromFile("textures/Theme.png");
	sf::Sprite theme_sprite(theme_texture);





	//////////////////////////////////////////////////////////////////////////////////////////////////
	//player
	sf::Texture stateczek;
	stateczek.loadFromFile("textures/fighter-01.png");
	Player player1(stateczek, sf::Vector2f(ScreenWidth / 2, ScreenHeight / 2),50, 100, 100, 5,0.5);
	player1.exists = false;//narazie niech zostanie

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//bron
	sf::Texture pocisk_tekstura;
	pocisk_tekstura.loadFromFile("textures/Red_laser.png");
	Bullet bullet1(pocisk_tekstura, player1.getPosition(),5, 50);//parametry
	bullet1.set_forward_deviation(50);
	Weapon weapon1(bullet1, 100,15,1);//rodzaj broni, 2 argument oznacza ile max strzalow moze byc na ekranie, 3 argument to speed
	//ostatni argument-firerate "1" oznacza 1 strzal na sekunde itd

	sf::Texture pocisk_tekstura2;
	pocisk_tekstura2.loadFromFile("textures/Yellow_ball.png");
	Bullet bullet2(pocisk_tekstura2, player1.getPosition(), 20, 100);//parametry
	bullet2.set_forward_deviation(50);
	Weapon weapon2(bullet2, 100, 15, 1);




	//interfejs
	sf::Font font1;
	font1.loadFromFile("fonts/optimus/Optimus Bold.otf");

	Interface player_interface(font1);


	//////////////////////////////////////////////////////////////////////////////////////////////////
	//Przeciwnik
	sf::Texture Basic_enemy_texture;
	Basic_enemy_texture.loadFromFile("textures/Basic_enemy.png");
	Enemy Basic_enemy(Basic_enemy_texture, sf::Vector2f(600,-100),40, 100, 10);
	Basic_enemy.setRotation(180);


	//timer
	Timer supporting_timer;

	//spawner
	Enemy_spawner spawner1(Basic_enemy,100);




	srand(time(0));
	while (MainWindow.isOpen())
	{

		while (MainWindow.pollEvent(event))
		{

			if (event.type == sf::Event::Closed)
			{

				MainWindow.close();
			}
		}

		if (player1.exists == false)
		{
			player_interface.main_Menu(MainWindow,player1);
		}
		else
		{
			MainWindow.draw(theme_sprite);



			player1.draw(MainWindow);
			player1.Controller(MainWindow);
			player1.energy_regen(1, 100);



			//strzelanie
			weapon1.DrawBullet(MainWindow);
			weapon1.Move_bullet_with_collision(MainWindow, spawner1.return_objects(), true);
			weapon2.DrawBullet(MainWindow);
			weapon2.Move_bullet_with_collision(MainWindow, spawner1.return_objects(), false);




			if (player1.canShoot == false)
			{
				weapon1.CheckBulletClock(player1);

			}
			if (player1.canShoot&&sf::Mouse::isButtonPressed(sf::Mouse::Left))
			{
				weapon1.shoot(player1);
			}

			if (player1.canShoot&&sf::Mouse::isButtonPressed(sf::Mouse::Right) && player1.get_Energy() >= 20)
			{
				weapon2.shoot_and_consume_energy(player1, 20);
			}




			spawner1.spawn(2000);
			spawner1.draw(MainWindow);
			spawner1.AI_move_with_surround(3, 3, player1, 300);
			spawner1.collision_with_player(player1);





			//interfejs
			player_interface.draw_HP(player1, MainWindow);
			player_interface.draw_Energy(player1, MainWindow);

		}

		MainWindow.display();
		MainWindow.clear();




	}









	//do zrobienia
	//strzelanie enemy
	//menu
	//losowy spawn


	return 0;
}

