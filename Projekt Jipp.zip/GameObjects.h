#pragma once
#include <SFML\Graphics.hpp>

#define _USE_MATH_DEFINES
#include <math.h>


#include "Timer.h"



class GameObject
{


protected:
	sf::Sprite sprite;
	sf::CircleShape collider;

public:
	

	GameObject(sf::Texture &texture, sf::Vector2f position,float collider_radius) :exists(false)
	{	
		this->sprite.setTexture(texture);
		this->sprite.setOrigin(texture.getSize().x / 2, texture.getSize().y / 2);
		this->sprite.setPosition(position);
		this->collider.setOrigin(collider_radius,collider_radius);
		this->collider.setRadius(collider_radius);
		this->collider.setPosition(position);
		this->collider.setFillColor(sf::Color::Green);
	}
	~GameObject()
	{

	}

	//ustawianie parametrow
	virtual void setPosition(sf::Vector2f position)
	{
		this->sprite.setPosition(position);
		this->collider.setPosition(position);
	}
	virtual void setPosition(float x, float y)
	{
		this->sprite.setPosition(x,y);
		this->collider.setPosition(x,y);
	}
	virtual void setRotation(float angle)
	{
		this->sprite.setRotation(angle);
	}

	virtual void setCollider_Radius(float x)
	{
		this->collider.setRadius(x);
	}

	//odczyt parametrow
	virtual sf::Vector2f getPosition()
	{
		return this->sprite.getPosition();
	}
	virtual sf::Sprite getSprite()
	{
		return this->sprite;
	}
	virtual sf::CircleShape getCollider()
	{
		return this->collider;
	}
	virtual float getRotation()
	{
		return this->sprite.getRotation();
	}

	

	// poruszanie
	void move(sf::Vector2f position)
	{
		this->sprite.move(position);
		this->collider.move(position);
	}
	void move(float x, float y)
	{
		this->sprite.move(x, y);
		this->collider.move(x, y);
	}

	//czy istnieje
	bool exists;//ma byc ustawiane przez funkcje spawnujaca


	virtual void draw(sf::RenderWindow &window)
	{
		if(this->exists)
		window.draw(this->sprite);
		//window.draw(this->collider);
	}




};





class Player : public GameObject
{
private:
	int hp;
	int energy;
	float speed;
	float acceleration;

	Timer timer;

	float curr_speed = 0;
public:

	bool canShoot;

	Player(sf::Texture &texture, sf::Vector2f position,float radius,int hp, int energy, float speed,float acceleration):GameObject(texture,position,radius),hp(hp),energy(energy),speed(speed),acceleration(acceleration),canShoot(true)
	{

	}

	void change_speed(float value)
	{
		this->speed = value;
	}

	void change_acceleration(float value)
	{
		this->acceleration = value;
	}

	int get_HP()
	{
		return this->hp;
	}

	int get_Energy()
	{
		return this->energy;
	}


	void get_damage(int value)
	{
		this->hp -= value;
		if (this->hp <= 0)
		{
			exists = false;
		}
	}

	void lose_energy(int value)
	{
		if(energy>0)
		this->energy -= value;

	}

	void energy_regen(int value, int time_miliseconds)
	{
		if (this->timer.Basic_spawner(time_miliseconds)&&this->energy<100)
		{
			if (this->energy > 100) this->energy = 100;

			this->energy += value;
		}
	}


	void Controller(sf::RenderWindow &window)
	{
		if (this->sprite.getPosition().x > window.getSize().x-25)
			this->sprite.setPosition(this->sprite.getPosition().x + (-5), this->sprite.getPosition().y);

		if (this->sprite.getPosition().x < 0 + 25)
			this->sprite.setPosition(this->sprite.getPosition().x + 5, this->sprite.getPosition().y);

		if (this->sprite.getPosition().y > window.getSize().y - 25)
			this->sprite.setPosition(this->sprite.getPosition().x, this->sprite.getPosition().y + (-5));

		if (this->sprite.getPosition().y <0 + 25)
			this->sprite.setPosition(this->sprite.getPosition().x, this->sprite.getPosition().y + 5);



		sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
		sf::Vector2f playerPosition = this->sprite.getPosition();



		float radian = atan2(mousePosition.x - playerPosition.x, mousePosition.y - playerPosition.y);
		float angle = 180 * radian / M_PI;
		
		this->sprite.setRotation(-angle + 180);


	
		//(jak bedzie czas)dodac zmienna bool, jezeli przycisk nie jest wcisniety wyzerowac velocity, moze dodam opoznione zatrzymanie jak starczy czasu teraz to malo istotne

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		{
			this->curr_speed+= acceleration;
			if (curr_speed > this->speed)curr_speed = this->speed;


			this->move(0.0f, -curr_speed);

		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		{

			curr_speed += acceleration;
			if (curr_speed > this->speed)curr_speed = this->speed;


			this->move(0.0f, curr_speed);
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		{

			curr_speed += acceleration;
			if (curr_speed > this->speed)curr_speed = this->speed;


			this->move(-curr_speed, 0.0f);
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		{

			curr_speed += acceleration;
			if (curr_speed > this->speed)curr_speed = this->speed;


			this->move(curr_speed, 0.0f);
		}

		if (!sf::Keyboard::isKeyPressed(sf::Keyboard::W)&& !sf::Keyboard::isKeyPressed(sf::Keyboard::S) && !sf::Keyboard::isKeyPressed(sf::Keyboard::D)&& !sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		{
			curr_speed =0;
		}




	}





};



class Enemy : public GameObject
{
private:
	int hp;
	int damage;



public:
	bool died = false;
	bool too_close = false;

	Enemy(sf::Texture &texture, sf::Vector2f position, float radius, int hp, int damage) : GameObject(texture, position, radius), hp(hp), damage(damage)
	{
	}

	~Enemy()
	{}

	bool check_collision(Player &player)
	{
		if (this->collider.getGlobalBounds().intersects(player.getCollider().getGlobalBounds()) && this->exists&&player.exists)
			return true;
		else return false;
	}


	void get_damage(int value)
	{
		this->hp -= value;
		if (this->hp <= 0)
		{
			exists = false;
			died = true;
		}
	}


	void move_around(float x_speed, float y_speed, Player &player)
	{
		float angleX = cos(atan2f(this->getPosition().x - player.getPosition().x, this->getPosition().y - player.getPosition().y));
		float angleY = sin(atan2f(this->getPosition().x - player.getPosition().x, this->getPosition().y - player.getPosition().y));


		this->move(-x_speed * angleX, y_speed * angleY);


	}

	void move_to_player(float x_speed, float y_speed, Player &player)
	{

		this->move(x_speed*(player.getPosition().x - this->getPosition().x)*0.002, y_speed*(player.getPosition().y - this->getPosition().y)*0.002);

	}




};




