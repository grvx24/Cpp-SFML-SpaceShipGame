#pragma once
#include <SFML\Graphics.hpp>
#include "GameObjects.h"
#include <vector>

class Bullet :public GameObject
{
private:
	int damage;
	float forward_dev;//domyslnie pocisk wylatuje ze srodka objektu
	float side_dev;//te zmienne decyduja o odchyleniu od srodka objektu

public:
	float angle; //kierunek strzalu ;)

	Bullet(sf::Texture &texture, sf::Vector2f position, float radius, int damage) :GameObject(texture, position,radius), damage(damage), angle(0), forward_dev(0), side_dev(0)
	{

	}
	void setDamage(int damage)
	{
		this->damage = damage;
	}



	//ustawienie odchylenia dla pionu i poziomu
	void set_forward_deviation(float value)
	{
		this->forward_dev = value;
	}

	void set_side_deviation(float value)
	{
		this->side_dev = value;
	}

	void shoot(Player &player, sf::Clock &bulletClock)
	{
		this->angle = (player.getRotation() - 90) *M_PI / 180;
		sf::Vector2f forward_deviation = sf::Vector2f(cos(angle)*forward_dev, sin(angle)*forward_dev);
		sf::Vector2f side_deviation = sf::Vector2f(sin(angle)*side_dev, cos(angle)*side_dev);


		this->exists = true;
		this->setPosition(player.getPosition()+forward_deviation+side_deviation);
		this->setRotation(player.getRotation());
		this->collider.setPosition(this->getPosition());
		this->collider.setRotation(player.getRotation());

		player.canShoot = false;

		bulletClock.restart();


	}


	bool check_collision(Enemy &enemy)
	{
		if (this->collider.getGlobalBounds().intersects(enemy.getCollider().getGlobalBounds())&&enemy.exists)
		{
			return true;
		}
		else return false;
	}


	void move(sf::RenderWindow &window,float speed)
	{

		this->sprite.move(speed*cos(angle), speed*sin(angle));
		this->collider.move(speed*cos(angle), speed*sin(angle));



		if (this->sprite.getPosition().x > window.getSize().x+25 || this->sprite.getPosition().x<-25 || this->sprite.getPosition().y>window.getSize().y+25 || this->sprite.getPosition().y < -25)
		{
			exists = false;
		}

	}

	void attack(Enemy &enemy)
	{
		enemy.get_damage(this->damage);
	}


	void move_with_collision(sf::RenderWindow &window, float speed, std::vector<Enemy> &enemies,bool disappear)
	{
		this->move(window, speed);

		for (int i = 0; i < enemies.size(); i++)
		{
			if (this->check_collision(enemies[i]) && exists == true)
			{
				//std::cout << "Kolizja z pociskiem" << std::endl;
				if(disappear)
				this->exists = false;
				attack(enemies[i]);
			}
		}

	}

};

//Sluzy do indeksowania tablicy pociskow, tak zeby indeks po osiagnieciu max zmienial sie na 0
class BulletData
{
public:

	int nextBullet;//liczba dostepnych pociskow

	BulletData():nextBullet(0){}
	void Next(int totalBullets)
	{
		if (nextBullet < totalBullets) nextBullet += 1;
		if (nextBullet == totalBullets) nextBullet = 0;

	}


};



class Weapon
{
private:
	std::vector<Bullet> bullets;
	float speed;
	float fire_rate;

	BulletData bData;


	sf::Clock bullet_clock;
	

public:
	Weapon(Bullet pattern,int num_of_bullets,float speed,float fire_rate):speed(speed),fire_rate(1000/fire_rate)
	{
		for (int i = 0; i < num_of_bullets; i++)
		{
			bullets.push_back(pattern);
			bullet_clock.restart();
		}
	}

	~Weapon()
	{
		bullets.clear();
	}



	void DrawBullet(sf::RenderWindow &window)
	{
		for (int i = 0; i < bullets.size(); i++)
		{
			if(bullets[i].exists)
			bullets[i].draw(window);
		}
	}

	


	void MoveBullet(sf::RenderWindow &window)
	{



		for (int i = 0; i < bullets.size(); i++)
		{

			if (bullets[i].exists) 
			{ 
				bullets[i].move(window, this->speed);
			}

		}

	}


	void Move_bullet_with_collision(sf::RenderWindow &window, std::vector<Enemy> &enemies,bool disappear)
	{
		for (int i = 0; i < bullets.size(); i++)
		{

			if (bullets[i].exists)
			{
				bullets[i].move_with_collision(window, this->speed,enemies, disappear);
			}

		}

	}

	void CheckBulletClock(Player &player) //tu nastepuje zmiana pocisku w tablicy co okreslony czas
	{

		sf::Time elapsed = bullet_clock.getElapsedTime();
		sf::Time delay = sf::milliseconds(fire_rate);

		if (elapsed > delay)
		{
			bData.Next(bullets.size());
			player.canShoot = true;
			//std::cout << "moze strzelac" << std::endl;
			bullet_clock.restart();



		}




	}


	void shoot(Player &player)
	{
		if (!bullets[bData.nextBullet].exists)
		{
			bullets[bData.nextBullet].shoot(player, bullet_clock);
		}
	}

	void shoot_and_consume_energy(Player &player,int energy_cost)
	{
		if (!bullets[bData.nextBullet].exists)
		{
			player.lose_energy(energy_cost);
			bullets[bData.nextBullet].shoot(player, bullet_clock);
		}
	}



	void consume_energy(Player &player, int energy)
	{
	}



};





