#pragma once

#include "GameObjects.h"

#include <cstdlib>
#include <string>
#include <SFML\Graphics.hpp>


class Interface
{
private:
	sf::Font font;


public:

	Interface(sf::Font font)
	{
		this->font = font;
	}


	bool CheckForMouseTrigger(sf::RectangleShape &rectangle, sf::RenderWindow &window)
	{

		int mouseX = sf::Mouse::getPosition().x;
		int mouseY = sf::Mouse::getPosition().y;

		sf::Vector2i windowPosition = window.getPosition();

		if (mouseX > rectangle.getPosition().x + windowPosition.x && mouseX < (rectangle.getPosition().x + rectangle.getGlobalBounds().width + windowPosition.x)
			&& mouseY > rectangle.getPosition().y + windowPosition.y + 30 && mouseY < (rectangle.getPosition().y + rectangle.getGlobalBounds().height + windowPosition.y + 30))
		{
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			{
				return true;
			}
			return false;
		}

		return false;

	}



	void main_Menu(sf::RenderWindow &window,Player &player)
	{
		sf::Font font1;
		font1.loadFromFile("fonts/optimus/Optimus Bold.otf");

		sf::Text start("Spacja: Start", font1, 100);
		start.setColor(sf::Color::Blue);
		start.setPosition(window.getPosition().x / 2, window.getPosition().y / 2);

		sf::Text wyjscie("Esc: Wyjscie", font1, 100);
		wyjscie.setColor(sf::Color::Blue);
		wyjscie.setPosition(window.getPosition().x / 2, window.getPosition().y / 2+300);

		window.draw(start);
		window.draw(wyjscie);


		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
		{
			player.exists = true;
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
		{
			exit(0);
		}




	}




	void draw_HP(Player &player,sf::RenderWindow &window)
	{
		std::string hp_num = std::to_string(player.get_HP());
	
		
		sf::Text hp_number(hp_num, this->font, 80);
		hp_number.setColor(sf::Color::Red);
		hp_number.setPosition(window.getSize().x - 400,window.getSize().y-100);


		window.draw(hp_number);



	}


	void draw_Energy(Player &player, sf::RenderWindow &window)
	{
		std::string hp_num = std::to_string(player.get_Energy());


		sf::Text hp_number(hp_num, this->font, 80);
		hp_number.setColor(sf::Color::Yellow);

		hp_number.setPosition(window.getSize().x - 200, window.getSize().y - 100);


		window.draw(hp_number);



	}

};