#pragma once
#include <SFML\Graphics.hpp>
#include <iostream>


class Timer
{
private:
	sf::Clock main_clock;


public:

	Timer()
	{

		main_clock.restart();
	}

	bool Basic_spawner(int milliseconds)
	{
		sf::Time elapsed = main_clock.getElapsedTime();
		sf::Time delay = sf::milliseconds(milliseconds);

		if (elapsed > delay)
		{
			main_clock.restart();
			return true;
		}
		return false;

	}
	


	int spawn_rand_int(int delay,int range)
	{
		sf::Time elapsed = main_clock.getElapsedTime();
		sf::Time d = sf::seconds(delay);

		if (elapsed > d)
		{
			srand(time(0));
			return (rand() % (range*2)-range);
		}


	}








};